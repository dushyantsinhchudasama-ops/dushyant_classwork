package com.tss.__jpa.controller;

import com.tss.__jpa.dto.PageResponseDto;
import com.tss.__jpa.dto.StudentRequestDto;
import com.tss.__jpa.dto.StudentResponseDto;
import com.tss.__jpa.entity.Student;
import com.tss.__jpa.error.Error;
import com.tss.__jpa.exception.StudentNotFoundByIDException;
import com.tss.__jpa.services.StudentService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

import static org.springframework.http.HttpStatus.CREATED;

@RestController
@RequestMapping("/app")
@RequiredArgsConstructor
public class StudentController {

    private final StudentService studentService;

//    @GetMapping("/students")
//    public ResponseEntity<List<StudentResponseDto>> getAll()
//    {
//        return new ResponseEntity<>(studentService.readAll(), HttpStatus.OK);
//    }

    @GetMapping("/students")
    public ResponseEntity<PageResponseDto<StudentResponseDto>> getAll(@RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "1") int size) {

        HttpHeaders headers = new HttpHeaders();
        headers.add("App-Name","JPA Testing app");
        headers.add("Version","1.0");

        return ResponseEntity.ok(studentService.readAll(page, size));
    }

    @GetMapping("/students/{id}")
    public Student getByID(@PathVariable Long id)
    {
        return studentService.getById(id);
    }

    @PostMapping("/student")
    public ResponseEntity<StudentResponseDto> addStudent(@RequestBody StudentRequestDto requestDto)
    {
//        return ResponseEntity.status(CREATED).body(studentService.addStudent(student));
        return new ResponseEntity<>(studentService.addStudent(requestDto), HttpStatus.CREATED);
    }

    //this method will be used for handlind the exceptions
    @ExceptionHandler(StudentNotFoundByIDException.class)
    public ResponseEntity<Error> handleStudentNotFoundByIDException(StudentNotFoundByIDException exception, HttpServletRequest request)
    {
        Error error = new Error(LocalDateTime.now(), HttpStatus.NOT_FOUND.value(), exception.getMessage(), request.getRequestURI());

        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }
}
