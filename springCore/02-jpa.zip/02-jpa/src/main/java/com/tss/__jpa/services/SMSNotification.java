package com.tss.__jpa.services;

import org.springframework.stereotype.Service;

@Service
public class SMSNotification implements Notification{
    @Override
    public void sendNotification(String message, String receiver) {

        System.out.println("Notification send through SMS to: " + receiver);

    }
}
